
const API_URL = location.origin + '/api';
let cart = JSON.parse(localStorage.getItem('cart')||'[]');

async function loadProducts(){
 const box=document.getElementById('productList');
 try{
  const r=await fetch(API_URL+'/products');
  const products=await r.json();
  const list = Array.isArray(products)?products:[];
  box.innerHTML=list.map(p=>`
  <div class="product-card">
   <img src="${p.image||'https://images.unsplash.com/photo-1523275335684-37898b6baf30'}">
   <h3>${p.name}</h3>
   <p>${p.price} جنيه</p>
   <button onclick="addToCart('${p._id}','${p.name}',${p.price})">🛒 أضف للسلة</button>
  </div>`).join('');
 }catch(e){box.innerHTML='<h3>تعذر تحميل المنتجات</h3>'}
}
function addToCart(id,name,price){
 cart.push({id,name,price});localStorage.setItem('cart',JSON.stringify(cart));
 alert('تمت الإضافة للسلة');
}
function openCart(){alert('عدد المنتجات في السلة: '+cart.length)}
loadProducts();

let currentLang=localStorage.getItem("lang")||"ar";
function toggleLang(){
 currentLang=currentLang==="ar"?"en":"ar";
 localStorage.setItem("lang",currentLang);
 document.documentElement.lang=currentLang;
 document.documentElement.dir=currentLang==="ar"?"rtl":"ltr";
 document.querySelectorAll("[data-ar]").forEach(e=>e.textContent=e.dataset[currentLang]);
}
if(currentLang==="en") toggleLang();
